import React, { useState, useEffect } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import Box from '@mui/material/Box';
import LinearProgress from '@mui/material/LinearProgress';
function App() {
  const [data, setdata] = useState([]);
  const [loading, setloading] = useState(true);

  const getdata = async () => {
    const fetchs = await fetch("https://reqres.in/api/users?page=1");
    const actualData = await fetchs.json();
    console.log(actualData.data);
    setdata(actualData.data);
    setloading(false);
  }
  useEffect(() => {
    getdata();
  }, [])

  const clear = () => {
    setdata([]);
  }
  if (loading) {
    return (
      <Box sx={{ width: '100%' ,transition:"2s" }}>
        <LinearProgress />
      </Box>
    )
  }
  return (
    <>
      <nav style={{ display: "flex", alignItems: "center", justifyContent: "space-between", width: "100%", height: "100px",
       background: "#ddd", marginBottom: "20px" }}>
        <h3 style={{ marginLeft: "10px", color: "magenta", fontSize: "60px" }}>React App</h3>
        <div>
          <button onClick={getdata} style={{ background: "gold", padding: "7px", border: "0px", outline: "none", 
          color: "#fff", margin: "20px" , fontSize: "22px"}} >Get Users</button>
          <button onClick={clear} style={{ background: "red", padding: "7px", border: "0px",
           outline: "none", color: "#fff", margin: "20px" , fontSize: "22px"}} >Clear Data</button>
        </div>
      </nav>

      <>
        <table className="table table-dark table-striped">
          <thead>
            <tr>
              <th scope="col">Email</th>
              <th scope="col">First Name</th>
              <th scope="col">Last Name</th>
              <th scope="col">Avatar</th>
            </tr>
          </thead>
          <tbody>
            {
              data.map(({ id, email, first_name, last_name, avatar }) => {
                return (
                  <tr key={id}>
                    <td>{email}</td>
                    <td className='recovered'>{first_name}</td>
                    <td className='death'>{last_name}</td>
                    <td className='click'>{avatar}</td>
                  </tr>
                )
              })
            }
          </tbody>
        </table>
      </>
    </>
  );
}

export default App;
